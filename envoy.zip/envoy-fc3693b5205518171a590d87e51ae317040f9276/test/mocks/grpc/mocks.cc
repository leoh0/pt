#include "mocks.h"

namespace Envoy {
namespace Grpc {

MockAsyncRequest::MockAsyncRequest() {}
MockAsyncRequest::~MockAsyncRequest() {}

MockAsyncClientFactory::MockAsyncClientFactory() {}
MockAsyncClientFactory::~MockAsyncClientFactory() {}

MockAsyncClientManager::MockAsyncClientManager() {}
MockAsyncClientManager::~MockAsyncClientManager() {}

} // namespace Grpc
} // namespace Envoy
