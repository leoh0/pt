#include "test/mocks/filesystem/mocks.h"

#include <string>

namespace Envoy {
namespace Filesystem {

MockFile::MockFile() {}
MockFile::~MockFile() {}

MockWatcher::MockWatcher() {}
MockWatcher::~MockWatcher() {}

} // namespace Filesystem
} // namespace Envoy
