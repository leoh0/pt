#include "mocks.h"

namespace Envoy {
namespace ExtAuthz {

MockClient::MockClient() {}
MockClient::~MockClient() {}

} // namespace ExtAuthz
} // namespace Envoy
