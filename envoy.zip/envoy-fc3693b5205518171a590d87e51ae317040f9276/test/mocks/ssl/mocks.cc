#include "mocks.h"

namespace Envoy {
namespace Ssl {

MockContextManager::MockContextManager() {}
MockContextManager::~MockContextManager() {}

MockConnection::MockConnection() {}
MockConnection::~MockConnection() {}

MockClientContext::MockClientContext() {}
MockClientContext::~MockClientContext() {}

} // namespace Ssl
} // namespace Envoy
