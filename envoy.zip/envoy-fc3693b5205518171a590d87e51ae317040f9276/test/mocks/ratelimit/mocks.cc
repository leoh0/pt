#include "mocks.h"

namespace Envoy {
namespace RateLimit {

MockClient::MockClient() {}
MockClient::~MockClient() {}

} // namespace RateLimit
} // namespace Envoy
